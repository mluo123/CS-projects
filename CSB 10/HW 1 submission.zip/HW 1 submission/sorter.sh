#! /bin/bash
while read line; 
do breed=$(echo "$line" | cut -f 3 | sed 's/\ /_/g');
	if [[ -e /mnt/c/Users/Latitude\ 7280/OneDrive/Desktop/CS10/Homework\ 1/DogsByBreed/$breed.txt ]]
		then 
			echo "$line" >> /mnt/c/Users/Latitude\ 7280/OneDrive/Desktop/CS10/Homework\ 1/DogsByBreed/$breed.txt
	else
		touch $breed.txt; 
		echo "$line" > $breed.txt; 
		mv $breed.txt /mnt/c/Users/Latitude\ 7280/OneDrive/Desktop/CS10/Homework\ 1/DogsByBreed;
	fi
done <AllBatchesNoHeader.tsv
