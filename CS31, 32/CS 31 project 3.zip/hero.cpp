#include <iostream>
#include <string>
#include <cassert>
#include <ctype.h>
using namespace std;

bool hasProperSyntax(string tune) 
{
	int i = 0;
	while(i != tune.size()) // Loop through the tune string
	{
		if (tune.at(i) == 'G' || tune.at(i) == 'g' || tune.at(i) == 'R' || tune.at(i) == 'r' || tune.at(i) == 'Y' || tune.at(i) == 'y' || tune.at(i) == 'B' || tune.at(i) == 'b' || tune.at(i) == 'O' || tune.at(i) == 'o') // Check if the beat is one of the given colors
		{
			if (i + 2 <= tune.size() && tune.at(i + 1) == '/')
				i += 2;
			else if (i + 3 <= tune.size() && isdigit(tune.at(i + 1)) && tune.at(i + 2) == '/')
				i += 3;
			else if (i + 4 <= tune.size() && isdigit(tune.at(i + 1)) && isdigit(tune.at(i + 2)) && tune.at(i + 3) == '/')
				i += 4;
			else
				return false;
		}
		else if (tune.at(i) == '/') // Check if it's just a beat
			i++;
		else
			return false;
	}
	return true;
}

int convertTune(string tune, string& instructions, int& badBeat)
{
	string yeet = "";
	if (hasProperSyntax(tune)) // Checks if tune is syntatically correct
	{
		int i = 0;
		while (i != tune.size()) // Loop through tune string
		{
			if (isalpha(tune.at(i))) // Checks if beat is a color
			{
				char letter = tune.at(i);
				if (isdigit(tune.at(i+1)) && isdigit(tune.at(i+2))) // If it has two digits, check if it's convertible
				{
					string temporary = tune.substr(i+1, 2);
					int length = stoi(temporary);
					if (length == 0 || length == 1)
					{
						badBeat = yeet.size() + 1;
						return 3;
					}
					else if (i + length + 3 > tune.size())
					{
						int counter = 0;
						for (int j = i + 3; j != tune.size(); j++)
							counter++;
						badBeat = yeet.size() + counter + 1;
						return 4;
					}
					else
					{
						for (int k = 0; k != length; k++)
						{
							if (tune.at(i+3+k) == '/')
								yeet += toupper(letter);
							else
							{
								badBeat = yeet.size() + 1;
								return 2;
							}
						}
					}
					i += 3 + length;
				}
				else if (isdigit(tune.at(i+1))) // Check if it's convertible for one digit
				{
					int length = tune.at(i+1) - 48;
					if (length == 0 || length == 1)
					{
						badBeat = yeet.size() + 1;
						return 3;
					}
					else if (i + length + 2 > tune.size())
					{
						int counter = 0;
						for (int j = i + 2; j != tune.size(); j++)
							counter++;
						badBeat = yeet.size() + counter + 1;
						return 4;
					}
					else
					{
						for (int k = 0; k != length; k++)
						{
							if (tune.at(i+2+k) == '/')
								yeet += toupper(letter);
							else
							{
								badBeat = yeet.size() + 1;
								return 2;
							}
						}
					}
					i += 2 + length;
				}
				else // If there's no number, write out beat to instructions
				{
					yeet += tolower(letter);
					i += 2;
				}
			}
			else // Add plain beat if there's no color
			{
				yeet += 'x';
				i++;
			}
		}
		instructions = yeet; // Set proper instructions if successful and return 0
		return 0;
	}
	else // Return result if tune doesn't even have proper syntax
		return 1;
}

int main()
{
	assert(hasProperSyntax("g/b//"));
	assert(!hasProperSyntax("g/z//"));
	assert(hasProperSyntax("r/"));
	assert(!hasProperSyntax("r"));
	assert(hasProperSyntax(""));
	assert(hasProperSyntax("/"));
	assert(hasProperSyntax("r3/"));
	assert(hasProperSyntax("y19/"));
	assert(!hasProperSyntax("g3"));
	assert(!hasProperSyntax("g34"));
	assert(!hasProperSyntax("9`=023857qo\ptreuiu�sadkjgghfdjk / zxcbmz / "));
	string instrs;
	int badb;
	badb = -999;  // so we can detect whether this gets changed
	assert(convertTune("r//g/", instrs, badb) == 0 && instrs == "rxg" && badb == -999);
	instrs = "WOW";  // so we can detect whether this gets changed
	badb = -999;  // so we can detect whether this gets changed
	assert(convertTune("r", instrs, badb) == 1 && instrs == "WOW" && badb == -999);
	assert(convertTune("r/y3//g/r/", instrs, badb) == 2 && instrs == "WOW" && badb == 4);
	assert(convertTune("y0/", instrs, badb) == 3 && instrs == "WOW" && badb == 1);
	assert(convertTune("b03/", instrs, badb) == 4 && instrs == "WOW" && badb == 2);
	assert(convertTune("g/r3//y/b0//o2/", instrs, badb) == 2 && instrs == "WOW" && badb == 4);
	assert(convertTune("g/r6//", instrs, badb) == 4 && instrs == "WOW" && badb == 4);
	cerr << "All tests succeeded" << endl;
}