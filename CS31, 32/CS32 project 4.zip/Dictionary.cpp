// Dictionary.cpp

#include "Dictionary.h"
#include <string>
#include <algorithm>
#include <cctype>
using namespace std;

void removeNonLetters(string& s);

const int max_buckets = 49999; // max number of possible buckets

class bucket // class for each bucket
{
public:
    bucket(string k, string v): Key(k), Value(v), next(nullptr) {} // Initialize Key, Value, and next 
    string Key;
    string Value;
    bucket* next;
};

class hashTable // class for hash table
{
public:
    hashTable(int maxbuckets);
    void insert(string key, string word);
    bucket* search(string key) const;
    ~hashTable();
private:   
    bucket** table; // array of linked lists
    int max_b, size; // ints to represent max buckets and current size of table
    std::hash<string> ind; // hash function to calculate indexes
};

hashTable::hashTable(int maxbuckets) // constructor of hash table
{
    // maxbuckets and size are initialized respectively
    max_b = maxbuckets; 
    size = 0;
    table = new bucket * [max_buckets]; // create array of linked lists
    for (int i = 0; i < max_buckets; i++)
        table[i] = nullptr; // initialize each element as null    
}

void hashTable::insert(string key, string word)
{
    int index = ind(key) % max_buckets; // index in table = mod of hash value of key and max amt of buckets
    // initialize bucket where word should be inserted, along w a prev
    bucket* prev = nullptr; 
    bucket* entry = table[index];
    while (entry != nullptr) // traverse through linked list until the end
    {
        prev = entry;
        entry = entry->next;
    }
    if (entry == nullptr) // if we've reached the end
    {
        entry = new bucket(key, word); // initialize entry as a new bucket value
        if (prev == nullptr) // if this is the first entry for this key, set it as the head, else link entry to the end
        {
            if (size == max_b)
                return;
            table[index] = entry;
            size++;
        }
        else
            prev->next = entry;
    }
    else // set value of entry as word input    
        entry->Value = word;   
}

bucket* hashTable::search(string key) const // return linked list for given key
{
    int index = ind(key) % max_buckets;
    return table[index];  
}

hashTable::~hashTable() // destructor for hash table
{
    for (int i = 0; i < max_buckets; i++) // traverse through each element of array
    {
        bucket* entry = table[i]; // initialize head of each linked list
        while (entry != nullptr) // delete nodes
        {
            bucket* del = entry;
            entry = entry->next;
            delete del;
        }
    }
    delete[] table; // delete array
}

class DictionaryImpl
{
public:
    DictionaryImpl(int maxBuckets): dict(maxBuckets) {}
    ~DictionaryImpl() {}
    void insert(string word);
    void lookup(string letters, void callback(string)) const;
private:
    hashTable dict;
};

void DictionaryImpl::insert(string word)
{
    removeNonLetters(word); 
    if (!word.empty()) // if word isn't empty after removing non letters
    {
        string keyword, Word; // initialize keyword and Word and turn it all lowercase 
        for (int i = 0; i < word.size(); i++)
        {
            keyword += tolower(word[i]);
            Word += tolower(word[i]);
        }
        sort(keyword.begin(), keyword.end()); // sort keyword
        dict.insert(keyword, Word); // insert into dictionary
    }
}

void DictionaryImpl::lookup(string letters, void callback(string)) const
{
    // if callback and/or letters is empty after removing non letters, return
    if (callback == nullptr)
        return;
    removeNonLetters(letters);
    if (letters.empty())
        return;
    string keyword; // initialize keyword
    for (int i = 0; i < letters.size(); i++) // turn all letters lowercase
        keyword += tolower(letters[i]);
    sort(keyword.begin(), keyword.end()); // sort letters to get key
    bucket* buck = dict.search(keyword); // get the linked list
    while (buck != nullptr) // traverse through linked list
    {
        if (buck->Key == keyword) // if key matches keyword, call function        
            callback(buck->Value);        
        buck = buck->next; // move to next node
    }
}

void removeNonLetters(string& s)
{
    for (int i = 0; i < s.size(); i++) // traverse through each letter of s
    {
        if (!isalpha(s[i])) // if character is not a letter, remove it        
            s.erase(s.begin() + i);
    }
}

//******************** Dictionary functions ******************************

// These functions simply delegate to DictionaryImpl's functions
// You probably don't want to change any of this code

Dictionary::Dictionary(int maxBuckets)
{
    m_impl = new DictionaryImpl(maxBuckets);
}

Dictionary::~Dictionary()
{
    delete m_impl;
}

void Dictionary::insert(string word)
{
    m_impl->insert(word);
}

void Dictionary::lookup(string letters, void callback(string)) const
{
    m_impl->lookup(letters, callback);
}