#pragma warning(disable : 6262)
#pragma warning(disable : 4996)
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cassert>
#include <cstring>
using namespace std;

const int MAX_WORD_LENGTH = 20;

int editStandards(int distance[], char word1[][MAX_WORD_LENGTH + 1], char word2[][MAX_WORD_LENGTH + 1], int nStandards)
{
	if (nStandards < 0)
		nStandards = 0;
	for (int i = 0; i < nStandards; i++) //Make every word lowercase
	{
		for (int j = 0; j < strlen(word1[i]); j++)
			word1[i][j] = tolower(word1[i][j]);
		for (int k = 0; k < strlen(word2[i]); k++)
			word2[i][k] = tolower(word2[i][k]);
	}
	for (int i = 0; i < nStandards; i++) //Sort into alphabetical order according to words in word1 array
	{
		for (int j = i + 1; j < nStandards; j++)
		{
			if (strcmp(word1[i], word1[j]) > 0) 
			{
				char temp[MAX_WORD_LENGTH + 1];
				strcpy(temp, word1[i]);
				strcpy(word1[i], word1[j]);
				strcpy(word1[j], temp);
				strcpy(temp, word2[i]);
				strcpy(word2[i], word2[j]);
				strcpy(word2[j], temp);
				int tempo = distance[i];
				distance[i] = distance[j];
				distance[j] = tempo;
			}
		}
	}
	for (int i = 0; i < nStandards; i++) // Remove non positive distances &/or empty strings
	{
		if (distance[i] <= 0 || strlen(word1[i]) == 0 || strlen(word2[i]) == 0)
		{
			distance[i] = 0;
			strcpy(word1[i], "");
			strcpy(word2[i], "");
		}
	}
	for (int i = 0; i < nStandards; i++) // Remove words with non alphabetic characters in them
	{
		for (int j = 0; j < strlen(word1[i]); j++) //Look through word1
		{
			if (!isalpha(word1[i][j]))
			{
				distance[i] = 0;
				strcpy(word1[i], "");
				strcpy(word2[i], "");
				break;
			}
		}
		for (int k = 0; k < strlen(word2[i]); k++) //Look through word2
		{
			if (!isalpha(word2[i][k]))
			{
				distance[i] = 0;
				strcpy(word1[i], "");
				strcpy(word2[i], "");
				break;
			}
		}
	}
	for (int i = 0; i < nStandards; i++) // Remove duplicates
	{
		if (strlen(word1[i]) == 0 && strlen(word2[i]) == 0 && distance[i] == 0) //If null, skip over it
			continue;
		for (int j = i + 1; j < nStandards; j++)
		{
			if (strcmp(word1[i], word1[j]) == 0 && strcmp(word2[i], word2[j]) == 0) //Find if next word is a duplicate
			{
				int highest = distance[i];
				int highInd = i;
				int k = j;
				while (k < nStandards && strcmp(word1[i], word1[k]) == 0 && strcmp(word2[i], word2[k]) == 0) //Find highest distance
				{
					if (distance[k] > highest)
					{
						highest = distance[k];
						highInd = k;
					}
					k++;
				}
				if (highest != distance[i] && highInd != i) //Put match standard with highest distance into first slot
				{
					char temp[MAX_WORD_LENGTH + 1];
					strcpy(temp, word1[i]);
					strcpy(word1[i], word1[highInd]);
					strcpy(word1[highInd], temp);
					strcpy(temp, word2[i]);
					strcpy(word2[i], word2[highInd]);
					strcpy(word2[highInd], temp);
					int tempo = distance[i];
					distance[i] = distance[highInd];
					distance[highInd] = tempo;
				}
				int m = j;
				while (m < nStandards && strcmp(word1[i], word1[m]) == 0 && strcmp(word2[i], word2[m]) == 0) //Actual removal of duplicates
				{
					distance[m] = 0;
					strcpy(word1[m], "");
					strcpy(word2[m], "");
					m++;
				}
				break;
			}
			else //Break out of loop if there is no duplicate right after
				break;
		}
	}
	int index = 0;
	for (int i = 0; i < nStandards; i++) //Put normal match standards into beginning of array
	{
		if (strlen(word1[i]) != 0 && strlen(word2[i]) != 0 && distance[i] > 0)
		{
			if (index == i) // If index and i are same, just increment index and leave alone
				index++;
			else
			{
				distance[index] = distance[i];
				strcpy(word1[index], word1[i]);
				strcpy(word2[index], word2[i]);
				index++;
			}
		}
	}
	return index;
}

int determineMatchLevel(const int distance[], const char word1[][MAX_WORD_LENGTH + 1], const char word2[][MAX_WORD_LENGTH + 1], int nStandards, const char jeet[])
{
	if (nStandards < 0)
		nStandards = 0;
	char words[140][280];
	int numWords = 0;
	int len = 0;
	for (int i = 0; i < strlen(jeet) + 1; i++) // Separate jeet into words in an array
	{
		if (jeet[i] == ' ' || jeet[i] == '\0') //Move onto next row if reached end of word and/or line
		{
			words[numWords][len] = '\0';
			numWords++;
			len = 0;
		}
		else if (!isalpha(jeet[i])) //If not a letter, ignore it
			continue;
		else //Put letters into array
		{
			words[numWords][len] = tolower(jeet[i]);
			len++;
		}
	}
	for (int i = 0; i < numWords; i++) //Loop through words array
	{
		if (strlen(words[i]) == 0) //Eliminate extra spaces
		{
			for (int j = i; j < numWords - 1; j++)
				strcpy(words[j], words[j + 1]);
			i--;
			numWords--; //Reduce number of words in array
		}
	}
	int numMatches = 0;
	for (int i = 0; i < nStandards; i++) // Find number of matches
	{
		for (int j = 0; j < numWords; j++)
		{
			if (strcmp(word1[i], words[j]) == 0) //Find where word1 is (if it exists)
			{
				for (int k = j + 1; k <= distance[i] + j; k++)
				{
					if (k >= numWords)
						break;
					else if (k < numWords && strcmp(word2[i], words[k]) == 0) //Find corresponding word2 if it's within distance
					{
						numMatches++;
						break;
					}
				}
				break;
			}
		}
	}
	return numMatches;
}

int main()
{
	const int TEST1_NSTANDARDS = 4;
	int test1dist[TEST1_NSTANDARDS] = {
		2,             4,         1,         13
	};
	char test1w1[TEST1_NSTANDARDS][MAX_WORD_LENGTH + 1] = {
		"eccentric",   "space",  "electric", "were"
	};
	char test1w2[TEST1_NSTANDARDS][MAX_WORD_LENGTH + 1] = {
		"billionaire", "capsule", "car", "eccentric"
	};

	const int TEST2_NSTANDARDS = 7;
	int test2dist[TEST2_NSTANDARDS] = { 2,4,1,3,2,1,13 };
	char test2w1[TEST2_NSTANDARDS][MAX_WORD_LENGTH + 1] = { "eccentric", "space", "ELECTRIC", "tunnel-boring", "space", "Electric", "were" };
	char test2w2[TEST2_NSTANDARDS][MAX_WORD_LENGTH + 1] = { "billionaire", "capsule", "CAR", "equipment", "capsule", "car", "eccentric"};

	int distances[7] = { -1, 3, 0, 2, 3, 1, 7 };
	char word1[7][MAX_WORD_LENGTH + 1] = { "", "PeopLe", "nope", "69th", "420", "nIcE", "people" };
	char word2[7][MAX_WORD_LENGTH + 1] = { "hello", "POPPER", "42@#!", "PickLes", "", "6969tt", "popper"};

	int Tdistances[3] = { 4, 3, 2 };
	char Tword1[3][MAX_WORD_LENGTH + 1] = { "hello", "darn", "puppy"};
	char Tword2[3][MAX_WORD_LENGTH + 1] = { "melinda", "it", "food"};

	assert(editStandards(distances, word1, word2, -5) == 0);
	assert(editStandards(distances, word1, word2, 7) == 1);
	assert(editStandards(test2dist, test2w1, test2w2, TEST2_NSTANDARDS) == 4);
	assert(determineMatchLevel(test1dist, test1w1, test1w2, TEST1_NSTANDARDS,
		"The eccentric outspoken billionaire launched a space station cargo capsule.") == 2);
	assert(determineMatchLevel(test1dist, test1w1, test1w2, TEST1_NSTANDARDS,
		"The eccentric outspoken billionaire launched    a space capsule.") == 2);
	assert(determineMatchLevel(test1dist, test1w1, test1w2, TEST1_NSTANDARDS,
		"**** 2022 ****") == 0);
	assert(determineMatchLevel(test1dist, test1w1, test1w2, TEST1_NSTANDARDS,
		"  It's an ELECTRIC car!") == 1);
	assert(determineMatchLevel(test1dist, test1w1, test1w2, TEST1_NSTANDARDS,
		"space space capsule space capsule capsule") == 1);
	assert(determineMatchLevel(test1dist, test1w1, test1w2, TEST1_NSTANDARDS,
		"Two eccentric billionaires were space-capsule riders.") == 0);
	assert(determineMatchLevel(Tdistances, Tword1, Tword2, -10, "idk man") == 0);
	assert(determineMatchLevel(Tdistances, Tword1, Tword2, 3, "69 420xxxxx PICKLES TASTE...      .. ..BAD") == 0);
	assert(determineMatchLevel(Tdistances, Tword1, Tword2, 3, "hello there melinda I like food idk what's up puppy darn darn darn it darn it it it darn hello food is very yummy I like it melinda") == 2);
	cout << "All tests succeeded" << endl;
}