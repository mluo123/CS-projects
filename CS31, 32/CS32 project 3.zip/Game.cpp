#include "Game.h"

Game::Game(const Board& b, Player* south, Player* north) : South(south), North(north), board(b), turn(SOUTH) {} // Initialize players and board. First turn is set to south

void Game::display() const // Print out the game
{
	std::cout << " " << North->name() << std::endl << " "; // First line displays north's name
	for (int i = 1; i <= board.holes(); i++) // Print out number of beans per hole on north side
		std::cout << board.beans(NORTH, i) << " ";
	std::cout << std::endl << board.beans(NORTH, 0) << std::string((board.holes() * 2) - 1, ' ') << board.beans(SOUTH, 0) << std::endl << " "; // Print out number of beans in pot for each side
	for (int i = 1; i <= board.holes(); i++) // Print out number of beans per hole on south's side
		std::cout << board.beans(SOUTH, i) << " ";
	std::cout << std::endl << " " << South->name() << std::endl; // Print out south's name
}

void Game::status(bool& over, bool& hasWinner, Side& winner) const
{
	if (board.beansInPlay(NORTH) == 0 || board.beansInPlay(SOUTH) == 0) // Check if game is over if any side has no beans left in holes
	{
		over = true;
		if (board.beans(SOUTH, 0) + board.beansInPlay(SOUTH) > board.beans(NORTH, 0) + board.beansInPlay(NORTH)) // If south has more beans, set hasWinner to true and winner as south
		{
			winner = SOUTH;
			hasWinner = true;
		}
		else if (board.beans(SOUTH, 0) + board.beansInPlay(SOUTH) < board.beans(NORTH, 0) + board.beansInPlay(NORTH)) // If north has more beans, set hasWinner to true and winner as north
		{
			winner = NORTH;
			hasWinner = true;
		}
		else // Game ended in draw
			hasWinner = false;
	}
	else
		over = false;
}

bool Game::move(Side s)
{	
	if (board.beansInPlay(s) == 0 || board.beansInPlay(opponent(s)) == 0) // Check if game is over
	{
		for (int i = 1; i <= board.holes(); i++) // Move all beans to pot
		{
			board.moveToPot(s, i, s);
			board.moveToPot(opponent(s), i, opponent(s));
		}
		return false; // Return false for game over
	}
	// Initialize side, end hole, and curr hole
	Side end;
	int holeEnd, hole;
	for (;;) // Infinitely loop until turn is complete
	{
		// Check which side is going
		if (s == NORTH) 
			hole = North->chooseMove(board, s);
		else
			hole = South->chooseMove(board, s);
		if (board.sow(s, hole, end, holeEnd)) // If move was successfully made
		{
			if (end == s && holeEnd == 0) // If last bean ended in a pot, make another move
			{
				display();
				std::cout << "An extra turn was gained." << std::endl;
				continue;
			}
			if (end == s && holeEnd != 0 && board.beans(s, holeEnd) == 1 && board.beans(opponent(s), holeEnd) > 0) // Check if move ended in a capture
			{
				board.moveToPot(s, holeEnd, s);
				board.moveToPot(opponent(s), holeEnd, s);
				std::cout << "A capture was made." << std::endl;
			}
			break;
		}
		else
			break; // Break out of loop if move didn't work
	}
	if (board.beansInPlay(s) == 0 || board.beansInPlay(opponent(s)) == 0) // If game is over, move beans to pots
	{
		display();
		std::cout << "Game is done, sweeping beans into pots" << std::endl;
		for (int i = 1; i <= board.holes(); i++)
		{
			board.moveToPot(s, i, s);
			board.moveToPot(opponent(s), i, opponent(s));
		}
	}
	return true; // Return true for complete move
}

void Game::play() 
{
	display();
	while (move(turn)) // While game is currently going
	{
		display(); // Display board
		if (!North->isInteractive() && !South->isInteractive()) // If both sides are CPU players
		{
			std::cout << "Press enter to continue"; // Continually prompt player to press enter
			std::cin.ignore(10000, '\n');
		}
		if (turn == SOUTH) // Switch sides after each turn
			turn = NORTH;
		else
			turn = SOUTH;
	}
	// Initialize variables for checking status
	bool over, win;
	Side winner;
	status(over, win, winner);
	if (win) // If game has a winner
	{
		switch (winner) // Print name of winner
		{
		case NORTH:
			std::cout << North->name() << " is the winner!" << std::endl;
			break;
		default:
			std::cout << South->name() << " is the winner!" << std::endl;
			break;
		}
	}
	else // Print game ended in a draw
		std::cout << "Game ended in a draw" << std::endl;
}

int Game::beans(Side s, int hole) const // return number of beans in specified hole and side
{
	return board.beans(s, hole);
}