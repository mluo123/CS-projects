#include "Board.h"

Board::Board(int nHoles, int nInitialBeansPerHole)
{
	if (nHoles <= 0) // Initialize number of holes; if less than or equal to 0, then set to 1
		Holes = 1;
	else
		Holes = nHoles;
	if (nInitialBeansPerHole < 0) // Initialize number of beans per hole; if less than 0, then set to 0
		initialBeans = 0;
	else
		initialBeans = nInitialBeansPerHole;
	// Initialize pots for each side
	north.push_back(0);
	south.push_back(0);
	for (int i = 1; i <= Holes; i++) // Fill holes with number of set beans per hole
	{
		north.push_back(initialBeans);
		south.push_back(initialBeans);
	}
}

int Board::holes() const // Return number of holes (not including pots)
{
	return Holes;
}

int Board::beans(Side s, int hole) const
{
	if (hole < 0 || hole > Holes) // Return -1 if hole is an invalid input	
		return -1;	
	// Return number of beans in specified hole and side
	if (s == SOUTH)
		return south[hole];
	else
		return north[hole];
}

int Board::beansInPlay(Side s) const
{
	int total = 0; // Initialize total
	if (s == SOUTH)
	{
		for (int i = 1; i <= Holes; i++)		
			total += south[i]; // Add up all of the beans on one side		
	}
	else
	{
		for (int i = 1; i <= Holes; i++)
			total += north[i];
	}
	return total; // Return number of beans for specified side
}

int Board::totalBeans() const
{
	int total = 0; // Initialize total
	for (int i = 0; i <= Holes; i++) // Traverse through all holes and add to total
		total += north[i] + south[i];
	return total; // Return total number of beans in holes and pots
}

bool Board::sow(Side s, int hole, Side& endSide, int& endHole)
{
	if (hole <= 0 || hole > Holes || (s == SOUTH && south[hole] == 0) || (s == NORTH && north[hole] == 0)) // If hole is invalid or empty, return false
		return false;
	if (s == SOUTH) // Sow south side
	{
		int num = south[hole]; // Get number of beans in specified hole to determine how many times to traverse
		south[hole] = 0; // Empty hole
		for (int i = hole + 1; i <= Holes; i++) // Move counterclockwise until end of side or num = 0
		{
			south[i]++; // Add a bean to each hole
			num--; // Decrease number of beans left
			if (num == 0) // If reached end of beans, return side and hole
			{
				endSide = SOUTH;
				endHole = i;
				return true;
			}
		}
		while (num != 0) // Keep traversing through holes until all beans are gone
		{
			south[0]++; // Add bean to pot 
			num--; // Decrease number of beans left
			if (num == 0) // If reached end of beans, return side and hole
			{
				endSide = SOUTH;
				endHole = 0;
				return true;
			}
			for (int i = Holes; i >= 1; i--) // Traverse through north side and end if necessary
			{
				north[i]++;
				num--;
				if (num == 0)
				{
					endSide = NORTH;
					endHole = i;
					return true;
				}
			}
			for (int i = 1; i <= Holes; i++) // Traverse through south side again and end if necessary
			{
				south[i]++;
				num--;
				if (num == 0)
				{
					endSide = SOUTH;
					endHole = i;
					return true;
				}
			}
		}
	}
	else // Sow north side
	{
		int num = north[hole]; // Initialize number of beans and empty hole
		north[hole] = 0;
		for (int i = hole - 1; i >= 0; i--) // Traverse through side, end until pot or number of beans is 0
		{
			north[i]++;
			num--;
			if (num == 0)
			{
				endSide = NORTH;
				endHole = i;
				return true;
			}
		}
		while (num != 0) // Keep dropping beans until they're gone
		{
			for (int i = 1; i <= Holes; i++) // Traverse through south side until end or number of beans left is 0
			{
				south[i]++;
				num--;
				if (num == 0)
				{
					endSide = SOUTH;
					endHole = i;
					return true;
				}
			}
			for (int i = Holes; i >= 0; i--) // Traverse through north side again, end until pot reached or number of beans left is 0
			{
				north[i]++;
				num--;
				if (num == 0)
				{
					endSide = NORTH;
					endHole = i;
					return true;
				}
			}
		}
	}
	return true;
}

bool Board::moveToPot(Side s, int hole, Side potOwner)
{
	if (hole <= 0 || hole > Holes) // If hole is invalid, return false
		return false;
	int amt; // Initialize amount to put into pot
	switch (s) // Set amt to number of beans and empty hole
	{
	case NORTH:
		amt = north[hole];
		north[hole] = 0;
		break;
	default:
		amt = south[hole];
		south[hole] = 0;
		break;
	}
	switch (potOwner) // Put beans into pot
	{
	case NORTH:
		north[0] += amt;
		break;
	default:
		south[0] += amt;
		break;
	}
	return true; // Return true for being able to put beans into pot
}

bool Board::setBeans(Side s, int hole, int beans)
{
	if (hole < 0 || hole > Holes || beans < 0) // If hole or beans is invalid, return false
		return false;
	// Set hole to number of beans and return true
	if (s == SOUTH) 
		south[hole] = beans;
	else
		north[hole] = beans;
	return true;
}