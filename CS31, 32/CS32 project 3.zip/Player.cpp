#include "Player.h"

Player::Player(std::string name) // Construct player with name
{
	Name = name;
}

std::string Player::name() const // Return name of player
{
	return Name;
}

bool Player::isInteractive() const // Default is false (assuming computer player)
{
	return false;
}

Player::~Player() {} // Destructor for player

HumanPlayer::HumanPlayer(std::string name) : Player(name) {} // Construct human player with given name

bool HumanPlayer::isInteractive() const // Returns true for human player
{
	return true;
}

int HumanPlayer::chooseMove(const Board& b, Side s) const // Ask human player for move and return hole number they input
{
	if (b.beansInPlay(s) == 0) // Return -1 if game is over
		return -1;
	for (;;) // Iterate infinitely until valid hole is reached
	{
		std::cout << "Enter a valid hole number: ";
		int holenum;
		std::cin >> holenum;
		if (holenum > 0 && holenum <= b.holes())
		{
			if (b.beans(s, holenum) > 0) // Break out of loop if valid hole with beans in it is reached 
				return holenum;
			else 
				std::cout << "There are no beans in hole " << holenum << std::endl; // Print message if empty
		}
		else
			std::cout << "You must enter a hole number between 1 and " << b.holes() << std::endl; // Keep asking for valid hole number
	}
}

HumanPlayer::~HumanPlayer() {} // Destructor

BadPlayer::BadPlayer(std::string name) : Player(name) {} // Constructor

int BadPlayer::chooseMove(const Board& b, Side s) const // Choose a random move and return
{
	if (b.beansInPlay(s) == 0) // Return -1 if game is finished 
		return -1;
	for (int i = 1; i <= b.holes(); i++)
	{
		if (b.beans(s, i) > 0) // Return first available valid hole
		{
			std::cout << name() << " chooses hole " << i << std::endl;
			return i;
		}
	}
	return -1;
}

BadPlayer::~BadPlayer() {}

SmartPlayer::SmartPlayer(std::string name) : Player(name) {}

int SmartPlayer::chooseMove(const Board& b, Side s) const 
{
	double timeLimit = 4990;
	JumpyTimer timer(1000);
	if (b.beansInPlay(s) == 0) // If game is over, return -1
		return -1;
	// Initialize variables for checking the value, the hole number, and value at each node
	int hole, newMove = 0;
	int val = INT_MIN;
	for (int i = 1; i <= b.holes(); i++) // Traverse through all holes
	{
		if (b.beans(s, i) > 0)
		{
			newMove = minimax(b, s, 4, true, timer, timeLimit); // Call minimax function to determine value of each hole
			if (newMove >= val) // If hole has a greater value than the currently saved highest val, then update val and save the hole number
			{
				val = newMove;
				hole = i;
			}
		}
	}
	std::cout << name() << " chooses hole " << hole << std::endl;
	return hole; // Return hole number with highest value
}

int SmartPlayer::eval(const Board& b, Side s, bool curr) const
{
	if (b.beans(s, 0) > b.totalBeans() / 2 || ((b.beansInPlay(s) == 0 || b.beansInPlay(opponent(s)) == 0) && b.beans(s, 0) + b.beansInPlay(s) > b.beans(opponent(s), 0) + b.beansInPlay(opponent(s))))
		return INT_MAX; // Return infinity if s is slated to win or has won
	else if (b.beans(opponent(s), 0) > b.totalBeans() / 2 || ((b.beansInPlay(s) == 0 || b.beansInPlay(opponent(s)) == 0) && b.beans(s, 0) + b.beansInPlay(s) < b.beans(opponent(s), 0) + b.beansInPlay(opponent(s))))
		return INT_MIN; // Return negative infinity if opponent is slated to win or has won
	else if ((b.beansInPlay(s) == 0 || b.beansInPlay(opponent(s)) == 0) && b.beans(s, 0) + b.beansInPlay(s) == b.beans(opponent(s), 0) + b.beansInPlay(opponent(s)))
		return 0; // Return 0 if game ended in draw
	else if (curr)
		return b.beans(s, 0) - b.beans(opponent(s), 0); // Return difference in the number of beans in each pot
	else
		return b.beans(opponent(s), 0) - b.beans(s, 0);
}

int SmartPlayer::minimax(const Board& b, Side s, int depth, bool curr, JumpyTimer& t, double timeLim) const
{
	if (b.beansInPlay(s) == 0 || b.beansInPlay(opponent(s)) == 0 || depth == 0 || timeLim <= 0)// Base case: game is over, or time limit or max depth is reached, return eval for specified side
		return eval(b, s, curr); 
	int val; // Initialize val for comparison
	if (curr) // If it is s's turn (aiming to maximize the value)
	{
		val = INT_MIN;
		for (int i = 1; i <= b.holes(); i++) // Traverse through all holes
		{
			double thisBranchTimeLimit = timeLim / (b.holes() + 1 - i); // Set up a time limit for this hole
			double startTime = t.elapsed(); // Save start time
			int maxHole; // Initialize variable for finding values
			if (b.beans(s, i) > 0) // If hole has beans in it
			{
				Board temp(b);
				if (move(temp, s, i)) // Make a move and determine if s can go again, otherwise switch sides
					maxHole = minimax(temp, s, depth, true, t, thisBranchTimeLimit);
				else
					maxHole = minimax(temp, opponent(s), depth - 1, false, t, thisBranchTimeLimit);				
				if (val < maxHole) // Set val to value returned after evaluating node
					val = maxHole;
				timeLim -= (t.elapsed() - startTime); // Subtract time elapsed from time limit
				if (timeLim < 0) // Set to 0 if timeLim is less than 0
					timeLim = 0;
			}
		}
	}
	else // Opponent is going, aiming to minimize value
	{
		val = INT_MAX;
		for (int i = 1; i <= b.holes(); i++) // Traverse through each hole
		{
			double thisBranchTimeLimit = timeLim / (b.holes() + 1 - i); // Set up timer
			double startTime = t.elapsed(); // Save start time
			int minHole; // Initialize value
			if (b.beans(s, i) > 0) // If hole has beans in it
			{
				Board temp(b);
				if (move(temp, s, i)) // Make a move and determine if another move can be made again, otherwise switch sides
					minHole = minimax(temp, s, depth, false, t, thisBranchTimeLimit);
				else
					minHole = minimax(temp, opponent(s), depth - 1, true, t, thisBranchTimeLimit);
				if (val > minHole) // Set val to value returned after evaluating node
					val = minHole;
				timeLim -= (t.elapsed() - startTime); // Adjust time limit
				if (timeLim <= 0)
					timeLim = 0;
			}
		}
	}
	return val; // Return final value assigned at node
}

bool SmartPlayer::move(Board& b, Side s, int hole) const
{
	// Initialize side and end hole for making a move
	Side endSide;
	int endHole;
	if (b.sow(s, hole, endSide, endHole))
	{
		if (endSide == s && endHole == 0) // If last bean ended in a pot, return true for being able to make another move
			return true;
		if (endSide == s && endHole != 0 && b.beans(s, endHole) == 1 && b.beans(opponent(s), endHole) > 0) // If sow ended in a capture, move beans accordingly
		{
			b.moveToPot(s, endHole, s);
			b.moveToPot(opponent(s), endHole, s);
		}
	}
	return false; // Return false for end of turn
}

SmartPlayer::~SmartPlayer() {}