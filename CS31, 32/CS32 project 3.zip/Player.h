﻿#ifndef PLAYER_INCLUDED
#define PLAYER_INCLUDED
#include <string>
#include <iostream>
#include <climits>
#include <chrono>
#include "Board.h"

//========================================================================
// Timer t;                 // create and start a timer
// t.start();               // restart the timer
// double d = t.elapsed();  // milliseconds since timer was last started
//========================================================================

class Timer
{
public:
	Timer()
	{
		start();
	}
	void start()
	{
		m_time = std::chrono::high_resolution_clock::now();
	}
	double elapsed() const
	{
		std::chrono::duration<double, std::milli> diff =
			std::chrono::high_resolution_clock::now() - m_time;
		return diff.count();
	}
private:
	std::chrono::high_resolution_clock::time_point m_time;
};

// Advance jumpy timer only after jumpInterval calls to elapsed
class JumpyTimer
{
public:
	JumpyTimer(int jumpInterval)
		: m_jumpInterval(jumpInterval), m_callsMade(0)
	{
		actualElapsed();
	}
	double elapsed()
	{
		m_callsMade++;
		if (m_callsMade == m_jumpInterval)
		{
			m_lastElapsed = m_timer.elapsed();
			m_callsMade = 0;
		}
		return m_lastElapsed;
	}
	double actualElapsed()
	{
		m_lastElapsed = m_timer.elapsed();
		return m_lastElapsed;
	}
private:
	Timer m_timer;
	int m_jumpInterval;
	int m_callsMade;
	int m_lastElapsed;
};

class Player
{
public:
	Player(std::string name);
	//Create a Player with the indicated name.
		std::string name() const;
	//Return the name of the player.
		virtual bool isInteractive() const;
	//Return false if the player is a computer player.Return true if the player is human.Most kinds of players will be computer players.
		virtual int chooseMove(const Board & b, Side s) const = 0;
	//Every concrete class derived from this class must implement this function so that if the player were to be playing side s and had to make a move given board b, the function returns the move the player would choose.If no move is possible, return −1.
		virtual ~Player();
	//Since this class is designed as a base class, it should have a virtual destructor.
private:
	std::string Name; // Name of player
};

class HumanPlayer : public Player
{
public:
	HumanPlayer(std::string name); //Create human Player with the indicated name.
	bool isInteractive() const; // Returns true, as is human player
	int chooseMove(const Board& b, Side s) const; // A HumanPlayer chooses its move by prompting a person running the program for a move (reprompting if necessary until the person enters a valid hole number), and returning that choice.
	~HumanPlayer(); // Destroys Human Player
};


class BadPlayer : public Player
{
public: 
	BadPlayer(std::string name); //Create bad CPU Player with the indicated name.
	int chooseMove(const Board& b, Side s) const; // A BadPlayer is a computer player that chooses an arbitrary valid move and returns that choice. "Arbitrary" can be what you like: leftmost, nearest to pot, fewest beans, random, etc.. The point of this class is to have an easy-to-implement class that at least plays legally.
	~BadPlayer(); // Destroys Bad Player
};

class SmartPlayer : public Player
{
public:
	SmartPlayer(std::string name); //Create smart CPU Player with the indicated name.
	int chooseMove(const Board& b, Side s) const; // A SmartPlayer chooses a valid move and returns it. For any game played on a board of up to six holes per side, with up to four initial beans per hole, SmartPlayer::chooseMove must return its choice in no more than five seconds
	~SmartPlayer(); // Destroys Smart Player
private:
	int eval(const Board& b, Side s, bool curr) const;
	int minimax(const Board& b, Side s, int depth, bool curr, JumpyTimer& t, double timeLim) const;
	bool move(Board& b, Side s, int hole) const;
};
#endif // !PLAYER_INCLUDED
