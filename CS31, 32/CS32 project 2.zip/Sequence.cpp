#include "Sequence.h"
#include <iostream>
#include <cstdlib>

Sequence::Sequence()
{
    head = nullptr;
    m_size = 0;
}

int Sequence::insert(int pos, const ItemType& value)
{
    if (pos < 0 || pos > m_size) // Immediately return if pos is out of bounds
        return -1;
    Node* p = new Node;
    p->value = value;
    if (pos == 0 || m_size == 0) // Check if pos belongs in first position
    {
        p->next = head;
        p->prev = nullptr;
        head = p;
    }
    else
    {
        Node* tmp = head;
        int count = 1;
        while (tmp->next != nullptr) // Iterate until desired position
        {
            if (count == pos)
                break;
            tmp = tmp->next;
            count++;
        }
        p->prev = tmp;
        if (pos != m_size)       // Check if pos is end of list or not in order to initialize "next"
            p->next = tmp->next;       
        else       
            p->next = nullptr;
        tmp->next = p;
    }
    m_size++;
    return pos;
}

int Sequence::insert(const ItemType& value)
{
    Node* p = new Node;
    p->value = value;
    int count = 0;
    if (m_size == 0 || (head != nullptr && value <= head->value)) // Check if value should go into first position
    {
        p->next = head;
        p->prev = nullptr;
        head = p;
    }
    else
    {
        Node* tmp = head;
        count++;
        while (tmp->next != nullptr) // Find where new node should go
        {
            if (value <= tmp->next->value)
                break;
            tmp = tmp->next;
            count++;
        }
        p->prev = tmp;
        if (count != m_size) // Check if value is placed at last position to initialize "next" properly
            p->next = tmp->next;
        else
            p->next = nullptr;       
        tmp->next = p;
    }
    m_size++;
    return count;
}

bool Sequence::erase(int pos)
{
    if (pos < 0 || pos >= size() || m_size == 0) // Check if pos is out of bounds or sequence is empty
        return false;
    if (pos == 0 || m_size == 1) // Check if pos is first position
    {
        Node* remove = head;
        head = remove->next;
        if (m_size != 1)
            head->prev = nullptr;
        delete remove;
    }
    else
    {
        Node* p = head;
        int count = 1;
        while (p != nullptr) // Iterate to desired position
        {
            if (p->next != nullptr && pos == count)
                break;
            p = p->next;
        }
        if (p != nullptr) // Remove node
        {
            Node* remove = p->next;
            p->next = remove->next;
            if (pos != m_size - 1)
                remove->next->prev = p;           
            delete remove;
        }
    }
    m_size--;
    return true;
}

int Sequence::remove(const ItemType& value)
{
    int dead = 0;
    Node* p = head;
    while (p != nullptr) // Iterate through linked list
    {
        if (p->value == value)
        {
            if (p == head) // If current pointer is head, remove properly
            {
                Node* remove = head;
                head = remove->next;
                if (m_size != 1)               
                    head->prev = nullptr; // Set prev to nullptr if there is more than one node currently
                p = head;
                delete remove;
                m_size--;
                dead++;
                if (m_size == 0) // Immediately return if list is now empty
                    return dead;
                continue;
            }
            else // Current pointer is not head, remove properly
            {
                Node* remove = p;
                if (p->next == nullptr) // Check if node is last item, or else initialize properly       
                    remove->prev->next = nullptr;                
                else
                {
                    remove->next->prev = remove->prev;
                    remove->prev->next = remove->next;
                }
                p = p->prev;
                delete remove;
                m_size--;
                dead++;
            }
        }
        p = p->next;
    }
    return dead;
}

bool Sequence::get(int pos, ItemType& value) const
{
    if (pos < 0 || pos >= size() || m_size == 0) // Immediately return if pos is out of bounds or list is empty
        return false;
    Node* p = head;
    int count = 0;
    while (p != nullptr) // Iterate to desired position
    {
        if (count == pos)
        {
            value = p->value; // Set value to item at p
            break;
        }
        p = p->next;
        count++;
    }
    return true;
}

bool Sequence::set(int pos, const ItemType& value)
{
    if (pos < 0 || pos >= size() || m_size == 0) // Immediately return if pos is out of bounds or list is empty
        return false;
    Node* p = head;
    int count = 0;
    while (p != nullptr)
    {
        if (count == pos) // Iterate to desired position
        {
            p->value = value; // Set item at p to value
            break;
        }
        p = p->next;
        count++;
    }
    return true;
}

int Sequence::find(const ItemType& value) const
{
    Node* p = head;
    int count = 0;
    while (p != nullptr) // Iterate through linked list
    {
        if (value == p->value)       
            return count; // Return position
        p = p->next;
        count++;
    }
    return -1; // Value not found
}

void Sequence::swap(Sequence& other)
{
    int temp_size = m_size; // Switch sizes
    m_size = other.m_size;
    other.m_size = temp_size;

    Node* temp_head = head; // Switch pointers to head
    head = other.head;
    other.head = temp_head;
}

Sequence::~Sequence()
{
    Node* p = head;
    while (p != nullptr)
    {
        Node* next = p->next; // Set next node and delete current node
        delete p;
        p = next;
    }
}

Sequence::Sequence(const Sequence& other)
{
    head = nullptr; // Initialize new pointer and size
    m_size = 0;
    for (int i = 0; i < other.m_size; i++) // Insert items into new linked list
    {
        ItemType val;
        other.get(i, val);
        insert(i, val); 
    }
}

Sequence& Sequence::operator=(const Sequence& rhs)
{
    if (this != &rhs) // Check to make sure there is no aliasing
    {
        Sequence temp(rhs);
        swap(temp); // Swap
    }
    return *this;
}

int subsequence(const Sequence& seq1, const Sequence& seq2)
{
    int pos = -1;
    if (seq1.empty() || seq2.empty() || seq1.size() < seq2.size()) // Check if seqs are empty or if seq2 size is larger than seq1 size
        return pos;
    int size = 0;
    ItemType val2;
    seq2.get(0, val2);
    for (int i = 0; i < seq1.size(); i++) // Iterate through seq1
    {
        ItemType val1;
        seq1.get(i, val1);
        if (val1 == val2) // Check to see where first values match
        {
            pos = i;
            int j = 0;
            int k = i;
            while (j < seq2.size() && k < seq1.size())
            {
                seq2.get(j, val2);
                seq1.get(k, val1);
                if (val1 == val2) // Iterate and check if vals are equal
                    size++;
                else
                    break;
                j++;
                k++;
            }
            if (size == seq2.size()) // If sizes are the same, return the pos
                return pos;
            else // Reset size and pos if they don't match
            {
                size = 0;
                pos = -1;
            }
        }
    }
    return pos;
}

void concatReverse(const Sequence& seq1, const Sequence& seq2, Sequence& result)
{
    int count = 0;
    Sequence res; // Initialize new sequence
    for (int i = seq1.size() - 1; i >= 0; i--) // Iterate backwards and put items into res
    {
        ItemType temp1;
        seq1.get(i, temp1);
        res.insert(count, temp1);
        count++;
    }
    for (int j = seq2.size() - 1; j >= 0; j--) // Iterate backwards and put items into res
    {
        ItemType temp2;
        seq2.get(j, temp2);
        res.insert(count, temp2);
        count++;
    }
    result = res; // Set result as res
}