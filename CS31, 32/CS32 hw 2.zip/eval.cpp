#include <stack>
#include <iostream>
#include <cassert>
#include <string>
using namespace std;

int evaluate(string infix, string& postfix, bool& result)
{
	string in;
	for (int k = 0; k < infix.size(); k++)
	{
		if (infix[k] == ' ')
			continue;
		else
			in += infix[k];
	}
	stack<char> Operator;
	postfix = "";
	int open = 0;
	int closed = 0;
	for (int i = 0; i < in.size(); i++)
	{
		switch (in[i])
		{
		case 'T':
		case 'F':
			if (i > 0 && (isalpha(in[i - 1]) || in[i - 1] == ')'))
				return 1;
			postfix += in[i];
			break;
		case '(':
			if (i == in.size() - 1 || (i > 0 && (isalpha(in[i - 1]) || in[i - 1] == ')')))
				return 1;
			open++;
			Operator.push(in[i]);
			break;
		case ')':
			closed++;
			if (i == 0 || closed > open || (i > 0 && !isalpha(in[i - 1]) && in[i - 1] != ')'))
				return 1;
			while (!Operator.empty() && Operator.top() != '(')
			{
				postfix += Operator.top();
				Operator.pop();
			}
			Operator.pop();
			break;
		case '&':
			if (i == 0 || i == in.size() - 1 || (i > 0 && !isalpha(in[i - 1]) && in[i - 1] != ')'))
				return 1;
			while (!Operator.empty() && Operator.top() != '(' && Operator.top() != '^')
			{
				postfix += Operator.top();
				Operator.pop();				
			}
			Operator.push(in[i]);
			break;
		case '^':
			if (i == 0 || i == in.size() - 1 || (i > 0 && !isalpha(in[i - 1]) && in[i - 1] != ')'))
				return 1;
			while (!Operator.empty() && Operator.top() != '(')
			{
				postfix += Operator.top();
				Operator.pop();
			}
			Operator.push(in[i]);
			break;
		case '!':
			if (i == in.size() - 1 || (i > 0 && (isalpha(in[i - 1]) || in[i - 1] == ')')))
				return 1;
			while (!Operator.empty() && Operator.top() != '(' && Operator.top() != '&' && Operator.top() != '^')
			{
				postfix += Operator.top();
				Operator.pop();				
			}
			Operator.push(in[i]);
			break;
		default:
			return 1;
		}
	}
	if (open != closed)
		return 1;
	while (!Operator.empty())
	{
		postfix += Operator.top();
		Operator.pop();
	}
	stack<char> Operand;
	for (int j = 0; j < postfix.size(); j++)
	{
		if (postfix[j] == 'T' || postfix[j] == 'F')
			Operand.push(postfix[j]);
		else if (postfix[j] == '!')
		{
			char oper = Operand.top();
			Operand.pop();
			if (oper == 'T')
				Operand.push('F');
			else
				Operand.push('T');
		}
		else
		{
			char operand1 = Operand.top();
			Operand.pop();
			char operand2 = Operand.top();
			Operand.pop();
			switch (postfix[j])
			{
			case '^':
				if (operand1 != operand2)
					Operand.push('T');
				else
					Operand.push('F');
				break;
			case '&':
				if (operand1 == 'F' || operand2 == 'F')
					Operand.push('F');
				else
					Operand.push('T');
				break;
			}
		}
	}
	if (Operand.size() != 1)
		return 1;
	if (Operand.top() == 'T')
		result = true;
	else
		result = false;
	return 0;
}

int main()
{
	string pf;
	bool answer;
	assert(evaluate("T^ F", pf, answer) == 0 && pf == "TF^" && answer);
	assert(evaluate("T^", pf, answer) == 1);
	assert(evaluate("F F", pf, answer) == 1);
	assert(evaluate("TF", pf, answer) == 1);
	assert(evaluate("()", pf, answer) == 1);
	assert(evaluate("()T", pf, answer) == 1);
	assert(evaluate("T(F^T)", pf, answer) == 1);
	assert(evaluate("T(&T)", pf, answer) == 1);
	assert(evaluate("(T&(F^F)", pf, answer) == 1);
	assert(evaluate("T|F", pf, answer) == 1);
	assert(evaluate("&&& & && && ^ ^^   ", pf, answer) == 1);
	assert(evaluate("F  ^  !F & (T&F) ", pf, answer) == 0 && pf == "FF!TF&&^" && !answer);
	assert(evaluate(" F  ", pf, answer) == 0 && pf == "F" && !answer);
	assert(evaluate("((T))", pf, answer) == 0 && pf == "T" && answer);
	assert(evaluate("T", pf, answer) == 0 && answer);
	assert(evaluate("(F)", pf, answer) == 0 && !answer);
	assert(evaluate("T^(F)", pf, answer) == 0 && answer);
	assert(evaluate("T ^ !F", pf, answer) == 0 && !answer);
	assert(evaluate("!(T&F)", pf, answer) == 0 && answer);
	assert(evaluate("!T&F", pf, answer) == 0 && !answer);
	assert(evaluate(" T^F&F", pf, answer) == 0 && answer);
	assert(evaluate("T&!(F^T&T^F)^!!!(F&T&F)", pf, answer) == 0 && answer);
	cout << "Passed all tests" << endl;
}