#include <queue>
#include <iostream>
using namespace std;

bool pathExists(char maze[][10], int sr, int sc, int er, int ec);

class Coord
{
public:
    Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
    int r() const { return m_r; }
    int c() const { return m_c; }
private:
    int m_r;
    int m_c;
};

bool pathExists(char maze[][10], int sr, int sc, int er, int ec)
{
    queue<Coord> coordQueue;
    coordQueue.push(Coord(sr, sc));
    maze[sr][sc] = '@';
    while (!coordQueue.empty())
    {
        Coord curr = coordQueue.front();
        coordQueue.pop();
        if (curr.r() == er && curr.c() == ec)
            return true;
        if (maze[curr.r() + 1][curr.c()] == '.')
        {
            coordQueue.push(Coord(curr.r() + 1, curr.c()));
            maze[curr.r() + 1][curr.c()] = '@';
        }
        if (maze[curr.r()][curr.c() + 1] == '.')
        {
            coordQueue.push(Coord(curr.r(), curr.c() + 1));
            maze[curr.r()][curr.c() + 1] = '@';
        }
        if (maze[curr.r() - 1][curr.c()] == '.')
        {
            coordQueue.push(Coord(curr.r() - 1, curr.c()));
            maze[curr.r() - 1][curr.c()] = '@';
        }
        if (maze[curr.r()][curr.c() - 1] == '.')
        {
            coordQueue.push(Coord(curr.r(), curr.c() - 1));
            maze[curr.r()][curr.c() - 1] = '@';
        }
    }
    return false;
}

int main()
{
    char maze[10][10] = {
        { 'X','X','X','X','X','X','X','X','X','X' },
        { 'X','.','.','.','X','.','.','.','.','X' },
        { 'X','.','.','X','X','.','X','X','.','X' },
        { 'X','.','X','.','.','.','.','X','X','X' },
        { 'X','X','X','X','.','X','X','X','.','X' },
        { 'X','.','.','X','.','.','.','X','.','X' },
        { 'X','.','.','X','.','X','.','.','.','X' },
        { 'X','X','.','X','.','X','X','X','X','X' },
        { 'X','.','.','.','.','.','.','.','.','X' },
        { 'X','X','X','X','X','X','X','X','X','X' }
    };

    if (pathExists(maze, 3, 4, 8, 1))
        cout << "Solvable!" << endl;
    else
        cout << "Out of luck!" << endl;
}