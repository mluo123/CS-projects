// Remove the restaurants in v with 2 or fewer stars and destroy them.
// It is acceptable if the order of the remaining restaurants is not
// the same as in the original vector.
void removeBad(vector<Restaurant*>& v)
{
	for (vector<Restaurant*>::iterator p = v.begin(); p != v.end(); p++)
	{
		if ((*p)->stars() <= 2)
		{
			vector<Restaurant*>::iterator temp = p;
			delete* temp;
			p = v.erase(p);
			p--;
		}
	}
}