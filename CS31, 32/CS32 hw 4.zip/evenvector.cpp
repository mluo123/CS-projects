// Remove the even integers from v.
// It is acceptable if the order of the remaining even integers is not
// the same as in the original vector.
void removeEven(vector<int>& v)
{
	for (vector<int>::iterator p = v.begin(); p != v.end(); p++)
	{
		if (*p % 2 == 0)
		{
			p = v.erase(p);
			p--;
		}
	}
}