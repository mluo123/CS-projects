// Remove the restaurants in li with 2 or fewer stars and destroy them.
// It is acceptable if the order of the remaining restaurants is not
// the same as in the original list.
void removeBad(list<Restaurant*>& li)
{
	for (list<Restaurant*>::iterator p = li.begin(); p != li.end(); p++)
	{
		if ((*p)->stars() <= 2)
		{
			list<Restaurant*>::iterator temp = p;
			delete *temp;
			p = li.erase(p);
			p--;
		}
	}
}