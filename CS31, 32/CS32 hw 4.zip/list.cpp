void listAll(const MenuItem* m, string path) // two-parameter overload
{
    for (vector<MenuItem*>::const_iterator p = m->menuItems()->begin(); p != m->menuItems()->end(); p++)
    {
        if ((*p)->menuItems() != nullptr)
        {
            cout << path + (*p)->name() << endl;
            listAll(*p, path + (*p)->name() + '/');
        }
        else       
            cout << path + (*p)->name() << endl;       
    }
}