#include <iostream>
#include <string>
using namespace std;

int main()
{	
	cout << "Initial meter reading: ";
	int initialMeterReading;
	cin >> initialMeterReading;
	
	cout << "Final meter reading: ";
	int finalMeterReading;
	cin >> finalMeterReading;
	cin.ignore(10000, '\n');

	cout << "Customer name: ";
	string customerName;
	getline(cin, customerName);

	cout << "Month number (1=Jan, 2=Feb, etc.): ";
	int monthNumber;
	cin >> monthNumber;

	int HCF = finalMeterReading - initialMeterReading;
	double bill;

	if (monthNumber >= 4 && monthNumber <= 10)
	{
		if (HCF > 23)
		{
			bill = 23 * 5.41 + (HCF - 23) * 9.79;
		}
		else
		{
			bill = HCF * 5.41;
		}
	}
	else
	{
		if (HCF > 15)
		{
			bill = 15 * 5.41 + (HCF - 15) * 7.77;
		}
		else
		{
			bill = HCF * 5.41;
		}
	}
	cout.setf(ios::fixed);
	cout.precision(2);
	
	cout << "---" << endl;
	if (initialMeterReading < 0)
	{
		cout << "The initial meter reading must not be negative." << endl;
	}
	else if (finalMeterReading < initialMeterReading)
	{
		cout << "The final meter reading must be at least as large as the initial reading." << endl;
	}
	else if (customerName == "")
	{
		cout << "You must enter a customer name." << endl;
	}
	else if (monthNumber < 1 || monthNumber > 12)
	{
		cout << "The month number must be in the range 1 through 12." << endl;
	}
	else
	{
		cout << "The bill for " << customerName << " is $" << bill << endl;
	}
}