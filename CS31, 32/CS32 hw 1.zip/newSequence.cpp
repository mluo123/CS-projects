#include "newSequence.h"

Sequence::Sequence()
{
	seq = new ItemType[DEFAULT_MAX_ITEMS];
	seq_size = 0;
	max_seqsize = DEFAULT_MAX_ITEMS;
}

Sequence::Sequence(int max_size)
{
	if (max_size < 0)
		std::exit;
	seq = new ItemType[max_size];
	seq_size = 0;
	max_seqsize = max_size;
}

Sequence::~Sequence()
{
	delete [] seq;
}

Sequence::Sequence(const Sequence& other)
{
	seq_size = other.seq_size;
	max_seqsize = other.max_seqsize;
	seq = new ItemType[max_seqsize];
	for (int i = 0; i < max_seqsize; i++)
		seq[i] = other.seq[i];	
}

Sequence& Sequence::operator=(const Sequence& rhs)
{
	if (this != &rhs)
	{
		Sequence temp(rhs);
		swap(temp);
	}
	return *this;
}

bool Sequence::empty() const
{
	return seq_size == 0;
}

int Sequence::size() const
{
	return seq_size;
}

int Sequence::insert(int pos, const ItemType& value)
{
	if (pos > seq_size || pos < 0 || seq_size == max_seqsize)
		return -1;
	if (seq_size == 0)
	{
		seq[0] = value;
		seq_size = 1;
		return pos;
	}
	for (int i = seq_size; i > pos; i--)
		seq[i] = seq[i - 1];
	seq[pos] = value;
	seq_size++;
	return pos;
}

int Sequence::insert(const ItemType& value)
{
	for (int i = 0; i < seq_size; i++)
	{
		if (value <= seq[i] && seq_size != max_seqsize)
		{
			for (int j = seq_size; j > i; j--)
				seq[j] = seq[j - 1];
			seq[i] = value;
			seq_size++;
			return i;
		}
	}
	if (seq_size != max_seqsize)
	{
		seq[seq_size] = value;
		seq_size++;
		return seq_size - 1;
	}
	return -1;
}

bool Sequence::erase(int pos)
{
	if (pos < 0 || pos >= seq_size)
		return false;
	for (int i = pos; i < seq_size - 1; i++)
		seq[i] = seq[i + 1];
	seq_size--;
	return true;
}

int Sequence::remove(const ItemType& value)
{
	int removed = 0;
	for (int i = 0; i < seq_size; i++)
	{
		if (seq[i] == value)
		{
			for (int j = i; j < seq_size - 1; j++)
				seq[i] = seq[i + 1];
			removed++;
			seq_size--;
		}
	}
	return removed;
}

bool Sequence::get(int pos, ItemType& value) const
{
	if (pos < 0 || pos >= seq_size)
		return false;
	value = seq[pos];
	return true;
}

bool Sequence::set(int pos, const ItemType& value)
{
	if (pos < 0 || pos >= seq_size)
		return false;
	seq[pos] = value;
	return true;
}

int Sequence::find(const ItemType& value) const
{
	for (int i = 0; i < seq_size; i++)
	{
		if (seq[i] == value)
			return i;
	}
	return -1;
}

void Sequence::swap(Sequence& other) 
{
	ItemType* temp = seq;
	int temp_size = seq_size;
	int temp_max = max_seqsize;

	seq = other.seq;
	seq_size = other.seq_size;
	max_seqsize = other.max_seqsize;

	other.seq = temp;
	other.seq_size = temp_size;
	other.max_seqsize = temp_max;
}