#include "RainfallList.h"

RainfallList::RainfallList():rainseq()
{
}

bool RainfallList::add(unsigned long rainfall)
{
	if (rainfall < 0 || rainfall > 400 || rainseq.size() == DEFAULT_MAX_ITEMS)
		return false;
	else
	{
		rainseq.insert(rainfall);
		return true;
	}
}

bool RainfallList::remove(unsigned long rainfall)
{
	return rainseq.erase(rainseq.find(rainfall));
}

int RainfallList::size() const
{
	return rainseq.size();
}

unsigned long RainfallList::minimum() const
{
	if (rainseq.empty())
		return NO_RAINFALLS;
	unsigned long lowest = 10000000000000000000;
	unsigned long val = 0;
	for (int i = 0; i < rainseq.size(); i++)
	{
		rainseq.get(i, val);
		if (val < lowest)
			lowest = val;
	}
	return lowest;
}

unsigned long RainfallList::maximum() const
{
	if (rainseq.empty())
		return NO_RAINFALLS;
	unsigned long highest = 0;
	unsigned long val = 0;
	for (int i = 0; i < rainseq.size(); i++)
	{
		rainseq.get(i, val);
		if (val > highest)
			highest = val;
	}
	return highest;
}