#include "Sequence.h"

Sequence::Sequence()
{
	seq_size = 0;
}

bool Sequence::empty() const
{
	return seq_size == 0;
}

int Sequence::size() const
{
	return seq_size;
}

int Sequence::insert(int pos, const ItemType& value)
{
	if (pos > seq_size || pos < 0 || seq_size == DEFAULT_MAX_ITEMS)
		return -1;
	if (seq_size == 0)
	{
		seq[0] = value;
		seq_size = 1;
		return pos;
	}
	for (int i = seq_size; i > pos; i--)
		seq[i] = seq[i - 1];
	seq[pos] = value;
	seq_size++;
	return pos;
}

int Sequence::insert(const ItemType& value)
{
	for (int i = 0; i < seq_size; i++)
	{
		if (value <= seq[i] && seq_size != DEFAULT_MAX_ITEMS)
		{
			for (int j = seq_size; j > i; j--)
				seq[j] = seq[j - 1];
			seq[i] = value;
			seq_size++;
			return i;
		}
	}
	if (seq_size != DEFAULT_MAX_ITEMS)
	{
		seq[seq_size] = value;
		seq_size++;
		return seq_size - 1;
	}
	return -1;
}

bool Sequence::erase(int pos)
{
	if (pos < 0 || pos >= seq_size)
		return false;
	for (int i = pos; i < seq_size - 1; i++)
		seq[i] = seq[i + 1];
	seq_size--;
	return true;
}

int Sequence::remove(const ItemType& value)
{
	int removed = 0;
	for (int i = 0; i < seq_size; i++)
	{
		if (seq[i] == value)
		{
			for (int j = i; j < seq_size - 1; j++)
				seq[i] = seq[i + 1];
			removed++;
			seq_size--;
		}
	}
	return removed;
}

bool Sequence::get(int pos, ItemType& value) const
{
	if (pos < 0 || pos >= seq_size)
		return false;
	value = seq[pos];
	return true;
}

bool Sequence::set(int pos, const ItemType& value)
{
	if (pos < 0 || pos >= seq_size)
		return false;
	seq[pos] = value;
	return true;
}

int Sequence::find(const ItemType& value) const
{
	for (int i = 0; i < seq_size; i++)
	{
		if (seq[i] == value)
			return i;
	}
	return -1;
}

void Sequence::swap(Sequence& other) 
{
	int large;
	if (seq_size > other.seq_size)
		large = seq_size;
	else
		large = other.seq_size;
	ItemType val;
	for (int i = 0; i < large; i++)
	{
		this->get(i, val);
		seq[i] = other.seq[i];
		other.seq[i] = val;
	}
	int temp_size = seq_size;
	other.seq_size = seq_size;
	seq_size = temp_size;
}