#include "RainfallList.h"
#include <iostream>
#include <cassert>

using namespace std;

void test()
{
	RainfallList yeet;
	assert(yeet.size() == 0);
	assert(!yeet.add(-1));
	assert(!yeet.add(420));
	assert(yeet.add(69));
	yeet.add(360);
	yeet.add(200);
	assert(yeet.size() == 3);
	assert(!yeet.remove(666));
	assert(yeet.remove(200));
	assert(yeet.size() == 2);
	assert(yeet.maximum() == 360);
	assert(yeet.minimum() == 69);
}

int main()
{
	test();
	cout << "Passed all tests" << endl;
}