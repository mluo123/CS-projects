#include <iostream>
#include <string>
#include <cassert>
using namespace std;
int enumerate(const string a[], int n, string target)
{
	if (n < 0)
		return -1;
	int counter = 0;
	for (int i = 0; i != n; i++) // find strings that equal target
	{
		if (a[i] == target)
			counter++;
	}
	return counter;
}
int findMatch(const string a[], int n, string target)
{
	if (n < 0)
		return -1;
	for (int i = 0; i != n; i++) // return first position of target
	{
		if (a[i] == target)
			return i;
	}
	return -1; // return -1 if such string not found
}
bool findRun(const string a[], int n, string target, int& begin, int& end)
{
	if (n < 0)
		return false;
	for (int i = 0; i != n; i++)
	{
		if (a[i] == target) //find starting position
		{
			begin = i;
			for (int j = i + 1; j < n; j++) // loop through array until last string is found
			{
				if (a[j] == target)
					continue;
				else
				{
					end = j-1;
					return true;
				}
			}
		}
	}
	return false; // return false if target is never found
}
int findMin(const string a[], int n)
{
	if (n <= 0)
		return -1;
	int earliest = 0; // initialize pos of min to first position
	string lesser = a[0]; 
	for (int i = 0; i != n; i++)
	{
		if (lesser > a[i])
		{
			lesser = a[i]; // set min to lowest
			earliest = i;
		}
	}
	return earliest;
}
int moveToEnd(string a[], int n, int pos)
{
	if (n < 0 || pos > n-1 || pos < 0)
		return -1;
	string name = a[pos]; // take string to move to end
	for (int i = pos; i < n-1; i++) // shift elements starting from pos to left
		a[i] = a[i + 1];
	a[n - 1] = name; // put desired string at end
	return pos;
}
int moveToBeginning(string a[], int n, int pos)
{
	if (n < 0 || pos > n-1 || pos < 0)
		return -1;
	string name = a[pos]; // take desired string
	for (int i = pos; i != 0; i--) // shift elements starting from pos to end to the right
		a[i] = a[i - 1];
	a[0] = name; // put desired string at beginning
	return pos;
}
int findDifference(const string a1[], int n1, const string a2[], int n2)
{
	if (n1 < 0 || n2 < 0)
		return -1;
	if (n1 < n2) // if n1 is smaller, loop through to find when they first don't match
	{
		for (int i = 0; i != n1; i++)
		{
			if (a1[i] != a2[i])
				return i;
		}
		return n1; // return n1 if they all match
	}
	else
	{
		for (int i = 0; i != n2; i++) // do the same as above for other cases
		{
			if (a1[i] != a2[i])
				return i;
		}
		return n2;
	}
}
int removeDups(string a[], int n)
{
	if (n < 0)
		return -1;
	for(int i = 0; i < n-1; i++) 
	{
		if (a[i] == a[i + 1]) // check if consecutive element is same as current element
		{
			int counter = 0;
			for (int j = i + 1; j != n; j++) // count how many times the string appears
			{
				if (a[i] == a[j])
					counter++;
				else
					break;
			}
			for (int k = i + 1; k != n-counter; k++) // cut out duplicates
				a[k] = a[k + counter];
		}
	}
	for (int i = 0; i < n-1; i++)
	{
		if (a[i] == a[i + 1]) // find last element before duplicates appear
			return i+1;
	}
	return n;
}
bool subsequence(const string a1[], int n1, const string a2[], int n2)
{
	if (n1 < 0 || n2 < 0 || n2 > n1)
		return false;
	int k = 0; // initialize starting point for finding elements
	int counter = 0;
	for (int i = 0; i != n2; i++)
	{
		for (int j = k; j != n1; j++)
		{
			if (a2[i] == a1[j]) //find where element in a2 appears and then set next pos to next element
			{
				k = j+1;
				counter++;
				break;
			}
		}
	}
	if (counter == n2) //return true if elements appear in same order
		return true;
	else
		return false;
}
int makeMerger(const string a1[], int n1, const string a2[], int n2, string result[], int max)
{
	if (n1 + n2 > max || n1 < 0 || n2 < 0)
		return -1;
	for (int i = 0; i != n1; i++)
	{
		for (int j = i+1; j != n1; j++)
		{
			if (a1[i] > a1[j]) // return -1 if elements are not in alphabetical order
				return -1;
		}
		result[i] = a1[i]; // put string into result if it works
	}
	for (int i = 0; i != n2; i++)
	{
		for (int j = i + 1; j != n2; j++)
		{
			if (a2[i] > a2[j]) // same as above, return -1 if not in alphabetical order, otherwise combine arrays together
				return -1;
		}
		result[n1 + i] = a2[i];
	}
	for (int i = 0; i != n1 + n2; i++) //sort by alphabetical order
	{
		for (int j = i + 1; j != n1 + n2; j++)
		{
			if (result[i] > result[j])
			{
				string temp = result[i];
				result[i] = result[j];
				result[j] = temp;
			}
		}
	}
	return n1 + n2;
}
int divide(string a[], int n, string divider)
{
	if (n < 0)
		return -1;
	for (int i = 0; i != n; i++) //sort array by alphabetical order
	{
		for (int j = i+1; j != n; j++)
		{
			if (a[i] > a[j])
			{
				string temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
	for (int i = 0; i != n; i++) //find position of where divider would be
	{
		if (a[i] >= divider)
			return i;
	}
	return n;
}
int main()
{
	string d[9] = { "clarence", "neil", "amy", "amy", "ketanji", "ketanji", "ketanji", "amy", "amy" };
	assert(enumerate(d, 9, "amy") == 4);
	assert(enumerate(d, 5, "ketanji") == 1);
	assert(enumerate(d, 9, "brett") == 0);
	assert(findMatch(d, 9, "ketanji") == 4);
	assert(findMatch(d, 4, "ketanji") == -1);
	int begin;
	int end;
	assert(findRun(d, 9, "amy", begin, end) && begin == 2 && end == 3);
	assert(findRun(d, 9, "neil", begin, end) && begin == 1 && end == 1);
	assert(!findRun(d, 9, "samuel", begin, end));
	assert(removeDups(d, 9) == 5 && d[3] == "ketanji");

	string people[5] = { "john", "sonia", "samuel", "elena", "neil" };
	string bench[6] = { "john", "sonia", "clarence", "elena", "neil", "samuel" };
	assert(findMin(people, 5) == 3);
	assert(moveToEnd(people, 4, 1) == 1 && people[1] == "samuel");
	assert(findDifference(people, 2, bench, 1) == 1);

	string big[10] = { "elena", "john", "amy", "ketanji", "neil", "amy" };
	string little1[10] = { "john", "ketanji", "neil" };
	string little2[10] = { "amy", "john" };
	string little3[10] = { "john", "amy", "amy" };
	string little4[10] = { "john", "john", "amy" };
	assert(subsequence(big, 6, little1, 3));
	assert(!subsequence(big, 6, little2, 2));
	assert(subsequence(big, 6, little3, 3));
	assert(!subsequence(big, 6, little4, 3));
	assert(subsequence(big, 6, little4, 0));

	string xx[5] = { "amy", "elena", "elena", "ketanji", "samuel" };
	string yy[4] = { "clarence", "elena", "john", "sonia" };
	string zz[20];
	assert(makeMerger(xx, 5, yy, 4, zz, 20) == 9 && zz[0] == "amy");

	string sc[6] = { "john", "amy", "samuel", "elena", "sonia", "neil" };
	string sc2[4] = { "john", "sonia", "amy", "neil" };
	assert(divide(sc, 6, "ketanji") == 3);
	assert(divide(sc2, 4, "neil") == 2);

	string h[7] = { "neil", "sonia", "john", "amy", "", "elena", "john" };
	assert(enumerate(h, 7, "john") == 2);
	assert(enumerate(h, 7, "") == 1);
	assert(enumerate(h, 7, "brett") == 0);
	assert(enumerate(h, 0, "john") == 0);
	assert(findMatch(h, 7, "john") == 2);
	assert(findMatch(h, 2, "john") == -1);
	int bg;
	int en;
	assert(findRun(h, 7, "amy", bg, en) && bg == 3 && en == 3);

	string g[4] = { "neil", "sonia", "amy", "elena" };
	assert(findMin(g, 4) == 2);
	assert(findDifference(h, 4, g, 4) == 2);
	assert(subsequence(h, 7, g, 4));
	assert(moveToEnd(g, 4, 1) == 1 && g[1] == "amy" && g[3] == "sonia");

	string f[4] = { "elena", "amy", "sonia", "john" };
	assert(moveToBeginning(f, 4, 2) == 2 && f[0] == "sonia" && f[2] == "amy");

	string e[5] = { "elena", "elena", "elena", "sonia", "sonia" };
	assert(removeDups(e, 5) == 2 && e[1] == "sonia");

	string x[4] = { "john", "john", "samuel", "sonia" };
	string y[4] = { "amy", "elena", "john", "ketanji" };
	string z[10];
	assert(makeMerger(x, 4, y, 4, z, 10) == 8 && z[5] == "ketanji");

	assert(divide(h, 7, "john") == 3);

	string a[2] = { "bob", "joe" };
	string b[3] = { "bob", "bob", "susan" };
	string c[5] = { "amy", "bob", "don", "joe", "sam" };
	string dee[420];
	string eat[2] = { "john", "carl" };
	string feet[3] = { "", "bob", "joe" };

	assert(enumerate(a, 2, "bob") == 1);
	assert(enumerate(a, -69, "john") == -1);
	assert(enumerate(a, 2, "john") == 0);
	assert(enumerate(a, 0, "john") == 0);
	assert(enumerate(a, 2, "") == 0);
	assert(findMatch(a, 2, "joe") == 1);
	assert(findMatch(a, -69, "john") == -1);
	assert(findMatch(a, 2, "john") == -1);
	assert(findMatch(a, 0, "john") == -1);
	assert(findMatch(a, 2, "") == -1);
	assert(findRun(b, 3, "bob", begin, end) && begin == 0 && end == 1);
	assert(!findRun(a, -69, "john", begin, end));
	assert(!findRun(a, 2, "john", begin, end));
	assert(!findRun(a, 0, "john", begin, end));
	assert(!findRun(b, 3, "", begin, end));
	assert(findMin(a, 2) == 0);
	assert(findMin(a, 0) == -1);
	assert(moveToEnd(a, 2, 0) == 0 && a[1] == "bob");
	assert(moveToEnd(a, -69, 0) == -1);
	assert(moveToEnd(a, 2, 420) == -1);
	assert(moveToEnd(a, 2, -69) == -1);
	assert(moveToEnd(a, 0, 0) == -1);
	assert(moveToBeginning(a, 2, 1) == 1);
	assert(moveToBeginning(a, -69, 1) == -1);
	assert(moveToBeginning(a, 2, 420) == -1);
	assert(moveToBeginning(a, 2, -69) == -1);
	assert(moveToBeginning(a, 0, 1) == -1);
	assert(findDifference(a, 2, b, 3) == 1);
	assert(findDifference(a, 1, b, 1) == 1);
	assert(findDifference(a, -69, b, -420) == -1);
	assert(findDifference(a, 0, b, 3) == 0);
	assert(removeDups(a, 2) == 2);
	assert(removeDups(b, 3) == 2);
	assert(removeDups(a, -69) == -1);
	assert(removeDups(a, 0) == 0);
	assert(subsequence(c, 5, a, 2));
	assert(!subsequence(c, 5, b, 3));
	assert(!subsequence(c, -69, b, -420));
	assert(!subsequence(b, 3, c, 5));
	assert(subsequence(c, 5, d, 0));
	assert(!subsequence(c, 0, b, 3));
	assert(makeMerger(b, 3, c, 5, dee, 420) == 8 && dee[0] == "amy");
	assert(makeMerger(b, 3, c, 5, dee, 1) == -1);
	assert(makeMerger(b, -69, c, -420, dee, 666) == -1);
	assert(makeMerger(c, 5, eat, 2, dee, 420) == -1);
	assert(makeMerger(b, 0, c, 5, dee, 420) == 5 && dee[0] == "amy");
	assert(makeMerger(b, 3, feet, 3, dee, 420) == 6 && dee[0] == "");
	assert(divide(a, 2, "carl") == 1);
	assert(divide(a, 2, "susan") == 2);
	assert(divide(a, 2, "abby") == 0);
	assert(divide(a, 2, "") == 0);
	assert(divide(a, 0, "carl") == 0);
	assert(divide(a, -69, "carl") == -1);

	cout << "All tests succeeded" << endl;
}