class Event
{
public:
    Event(string n);
    string name() const;
    virtual ~Event();
    virtual bool isSport() const;
    virtual string need() const = 0;
private:
    string Name;
};

class BasketballGame : public Event
{
public:
    BasketballGame(string game);
    string need() const;
    ~BasketballGame();
};

class HockeyGame : public Event
{
public:
    HockeyGame(string game);
    string need() const;
    ~HockeyGame();
};

class Concert : public Event
{
public:
    Concert(string artist, string g);
    bool isSport() const;
    string need() const;
    string genre() const;
    ~Concert();
private:
    string Genre;
};

Event::Event(string n) : Name(n) {}

BasketballGame::BasketballGame(string game) : Event(game) {}

HockeyGame::HockeyGame(string game) : Event(game) {}

Concert::Concert(string artist, string g): Event(artist), Genre(g) {}

string Event::name() const
{
    return Name;
}

bool Event::isSport() const
{
    return true;
}

bool Concert::isSport() const
{
    return false;
}

string BasketballGame::need() const
{
    return "hoops";
}

string HockeyGame::need() const
{
    return "ice";
}

string Concert::need() const
{
    return "a stage";
}

string Concert::genre() const
{
    return Genre;
}

Event::~Event() {}

BasketballGame::~BasketballGame()
{
    cout << "Destroying the " << name() << " basketball game" << endl;
}

HockeyGame::~HockeyGame()
{
    cout << "Destroying the " << name() << " hockey game" << endl;
}

Concert::~Concert()
{
    cout << "Destroying the " << name() << " " << genre() << " concert" << endl;
}